﻿namespace Accounting
{
    partial class form_appointment
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_appointment));
            this.trmnt_pnl = new System.Windows.Forms.Panel();
            this.alpha = new System.Windows.Forms.Label();
            this.trt_rmv = new System.Windows.Forms.Button();
            this.trt_add1 = new System.Windows.Forms.Button();
            this.romeo = new System.Windows.Forms.Label();
            this.sched_id1 = new System.Windows.Forms.Label();
            this.trmnt_cmb = new System.Windows.Forms.ComboBox();
            this.trt_id = new System.Windows.Forms.Label();
            this.countrows = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.trt_grid = new System.Windows.Forms.DataGridView();
            this.trt_cncl = new System.Windows.Forms.Button();
            this.trt_sve = new System.Windows.Forms.Button();
            this.trtmnts = new System.Windows.Forms.Label();
            this.trt_add = new System.Windows.Forms.Button();
            this.dctr_pnl = new System.Windows.Forms.Panel();
            this.dct_cn = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.dct_gnd = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.dct_age = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.dct_bd = new System.Windows.Forms.DateTimePicker();
            this.label17 = new System.Windows.Forms.Label();
            this.dct_adr = new System.Windows.Forms.TextBox();
            this.dct_ln = new System.Windows.Forms.TextBox();
            this.dct_fn = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.dct_ccl = new System.Windows.Forms.Button();
            this.dct_rst = new System.Windows.Forms.Button();
            this.dct_sve = new System.Windows.Forms.Button();
            this.doctor = new System.Windows.Forms.Label();
            this.ptn_pnl = new System.Windows.Forms.Panel();
            this.ptn_ccl = new System.Windows.Forms.Button();
            this.ptn_rst = new System.Windows.Forms.Button();
            this.pnl_sv = new System.Windows.Forms.Button();
            this.ptn_cn = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ptn_gnd = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ptn_age = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.ptn_bd = new System.Windows.Forms.DateTimePicker();
            this.label4 = new System.Windows.Forms.Label();
            this.ptn_adr = new System.Windows.Forms.TextBox();
            this.ptn_ln = new System.Windows.Forms.TextBox();
            this.ptn_fn = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ptn_lst_pnl = new System.Windows.Forms.Panel();
            this.ptn_nme = new System.Windows.Forms.TextBox();
            this.closeb = new System.Windows.Forms.Button();
            this.ptn_grid = new System.Windows.Forms.DataGridView();
            this.ptn_add = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.dct_lst_pnl = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.dct_nme = new System.Windows.Forms.TextBox();
            this.dct_close = new System.Windows.Forms.Button();
            this.dct_dgv = new System.Windows.Forms.DataGridView();
            this.dct_fnd = new System.Windows.Forms.Button();
            this.sched_id = new System.Windows.Forms.Label();
            this.docid = new System.Windows.Forms.Label();
            this.patientname = new System.Windows.Forms.Label();
            this.datetime = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.details = new System.Windows.Forms.GroupBox();
            this.rsts = new System.Windows.Forms.Button();
            this.src_dct = new System.Windows.Forms.Button();
            this.src_ptn = new System.Windows.Forms.Button();
            this.addsch = new System.Windows.Forms.Button();
            this.add_dtr = new System.Windows.Forms.Button();
            this.add_ptn = new System.Windows.Forms.Button();
            this.dctr_nm = new System.Windows.Forms.TextBox();
            this.dctr = new System.Windows.Forms.Label();
            this.trt_btn = new System.Windows.Forms.Button();
            this.es = new System.Windows.Forms.ComboBox();
            this.em = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ehr = new System.Windows.Forms.ComboBox();
            this.ss = new System.Windows.Forms.ComboBox();
            this.sm = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.shr = new System.Windows.Forms.ComboBox();
            this.dtpkr = new System.Windows.Forms.DateTimePicker();
            this.patn = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.endt = new System.Windows.Forms.Label();
            this.startt = new System.Windows.Forms.Label();
            this.appdate = new System.Windows.Forms.Label();
            this.patient = new System.Windows.Forms.Label();
            this.adschp = new System.Windows.Forms.Panel();
            this.FinishS = new System.Windows.Forms.Button();
            this.EditS = new System.Windows.Forms.Button();
            this.AddS = new System.Windows.Forms.Button();
            this.CancelS = new System.Windows.Forms.Button();
            this.Appointment = new System.Windows.Forms.Button();
            this.Schedule = new System.Windows.Forms.Button();
            this.dgv_app = new System.Windows.Forms.DataGridView();
            this.dgv_sched = new System.Windows.Forms.DataGridView();
            this.btn_allsched = new System.Windows.Forms.Button();
            this.btn_allapp = new System.Windows.Forms.Button();
            this.app_id = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dntid = new System.Windows.Forms.Label();
            this.panelista = new System.Windows.Forms.Panel();
            this.trmnt_pnl.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trt_grid)).BeginInit();
            this.dctr_pnl.SuspendLayout();
            this.ptn_pnl.SuspendLayout();
            this.ptn_lst_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptn_grid)).BeginInit();
            this.dct_lst_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dct_dgv)).BeginInit();
            this.details.SuspendLayout();
            this.adschp.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_app)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sched)).BeginInit();
            this.panelista.SuspendLayout();
            this.SuspendLayout();
            // 
            // trmnt_pnl
            // 
            this.trmnt_pnl.Controls.Add(this.alpha);
            this.trmnt_pnl.Controls.Add(this.trt_rmv);
            this.trmnt_pnl.Controls.Add(this.trt_add1);
            this.trmnt_pnl.Controls.Add(this.romeo);
            this.trmnt_pnl.Controls.Add(this.sched_id1);
            this.trmnt_pnl.Controls.Add(this.trmnt_cmb);
            this.trmnt_pnl.Controls.Add(this.trt_id);
            this.trmnt_pnl.Controls.Add(this.countrows);
            this.trmnt_pnl.Controls.Add(this.groupBox2);
            this.trmnt_pnl.Controls.Add(this.trt_cncl);
            this.trmnt_pnl.Controls.Add(this.trt_sve);
            this.trmnt_pnl.Controls.Add(this.trtmnts);
            this.trmnt_pnl.Controls.Add(this.trt_add);
            this.trmnt_pnl.Location = new System.Drawing.Point(13, 209);
            this.trmnt_pnl.Name = "trmnt_pnl";
            this.trmnt_pnl.Size = new System.Drawing.Size(481, 331);
            this.trmnt_pnl.TabIndex = 110;
            this.trmnt_pnl.Visible = false;
            // 
            // alpha
            // 
            this.alpha.AutoSize = true;
            this.alpha.Location = new System.Drawing.Point(5, 32);
            this.alpha.Name = "alpha";
            this.alpha.Size = new System.Drawing.Size(41, 13);
            this.alpha.TabIndex = 110;
            this.alpha.Text = "label22";
            this.alpha.Visible = false;
            // 
            // trt_rmv
            // 
            this.trt_rmv.BackColor = System.Drawing.SystemColors.Control;
            this.trt_rmv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.trt_rmv.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trt_rmv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.trt_rmv.Location = new System.Drawing.Point(208, 296);
            this.trt_rmv.Name = "trt_rmv";
            this.trt_rmv.Size = new System.Drawing.Size(87, 20);
            this.trt_rmv.TabIndex = 109;
            this.trt_rmv.Text = "Remove";
            this.trt_rmv.UseVisualStyleBackColor = false;
            this.trt_rmv.Click += new System.EventHandler(this.trt_rmv_Click);
            // 
            // trt_add1
            // 
            this.trt_add1.BackColor = System.Drawing.SystemColors.Control;
            this.trt_add1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trt_add1.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trt_add1.Location = new System.Drawing.Point(194, 96);
            this.trt_add1.Name = "trt_add1";
            this.trt_add1.Size = new System.Drawing.Size(40, 21);
            this.trt_add1.TabIndex = 108;
            this.trt_add1.Text = "Add";
            this.trt_add1.UseVisualStyleBackColor = false;
            this.trt_add1.Visible = false;
            this.trt_add1.Click += new System.EventHandler(this.trt_add1_Click);
            // 
            // romeo
            // 
            this.romeo.AutoSize = true;
            this.romeo.Location = new System.Drawing.Point(3, 14);
            this.romeo.Name = "romeo";
            this.romeo.Size = new System.Drawing.Size(41, 13);
            this.romeo.TabIndex = 106;
            this.romeo.Text = "label22";
            this.romeo.Visible = false;
            // 
            // sched_id1
            // 
            this.sched_id1.AutoSize = true;
            this.sched_id1.Location = new System.Drawing.Point(432, 46);
            this.sched_id1.Name = "sched_id1";
            this.sched_id1.Size = new System.Drawing.Size(41, 13);
            this.sched_id1.TabIndex = 105;
            this.sched_id1.Text = "label22";
            this.sched_id1.Visible = false;
            // 
            // trmnt_cmb
            // 
            this.trmnt_cmb.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.trmnt_cmb.FormattingEnabled = true;
            this.trmnt_cmb.Location = new System.Drawing.Point(30, 95);
            this.trmnt_cmb.Name = "trmnt_cmb";
            this.trmnt_cmb.Size = new System.Drawing.Size(148, 21);
            this.trmnt_cmb.TabIndex = 104;
            this.trmnt_cmb.SelectedIndexChanged += new System.EventHandler(this.trmnt_cmb_SelectedIndexChanged);
            this.trmnt_cmb.SelectionChangeCommitted += new System.EventHandler(this.trmnt_cmb_SelectionChangeCommitted);
            // 
            // trt_id
            // 
            this.trt_id.AutoSize = true;
            this.trt_id.Location = new System.Drawing.Point(433, 29);
            this.trt_id.Name = "trt_id";
            this.trt_id.Size = new System.Drawing.Size(41, 13);
            this.trt_id.TabIndex = 103;
            this.trt_id.Text = "label20";
            this.trt_id.Visible = false;
            // 
            // countrows
            // 
            this.countrows.AutoSize = true;
            this.countrows.Location = new System.Drawing.Point(433, 14);
            this.countrows.Name = "countrows";
            this.countrows.Size = new System.Drawing.Size(41, 13);
            this.countrows.TabIndex = 102;
            this.countrows.Text = "label20";
            this.countrows.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.trt_grid);
            this.groupBox2.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(30, 122);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(431, 157);
            this.groupBox2.TabIndex = 95;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Selected Treatments";
            // 
            // trt_grid
            // 
            this.trt_grid.AllowUserToAddRows = false;
            this.trt_grid.AllowUserToDeleteRows = false;
            this.trt_grid.AllowUserToResizeColumns = false;
            this.trt_grid.AllowUserToResizeRows = false;
            this.trt_grid.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.DisplayedCells;
            this.trt_grid.BackgroundColor = System.Drawing.Color.White;
            this.trt_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.trt_grid.Location = new System.Drawing.Point(6, 19);
            this.trt_grid.Name = "trt_grid";
            this.trt_grid.ReadOnly = true;
            this.trt_grid.RowHeadersVisible = false;
            this.trt_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.trt_grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.trt_grid.Size = new System.Drawing.Size(416, 132);
            this.trt_grid.TabIndex = 27;
            this.trt_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.trt_grid_CellContentClick);
            // 
            // trt_cncl
            // 
            this.trt_cncl.BackColor = System.Drawing.SystemColors.Control;
            this.trt_cncl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.trt_cncl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trt_cncl.Location = new System.Drawing.Point(332, 296);
            this.trt_cncl.Name = "trt_cncl";
            this.trt_cncl.Size = new System.Drawing.Size(87, 20);
            this.trt_cncl.TabIndex = 89;
            this.trt_cncl.Text = "Cancel";
            this.trt_cncl.UseVisualStyleBackColor = false;
            this.trt_cncl.Click += new System.EventHandler(this.trt_cncl_Click);
            // 
            // trt_sve
            // 
            this.trt_sve.BackColor = System.Drawing.SystemColors.Control;
            this.trt_sve.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.trt_sve.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trt_sve.ForeColor = System.Drawing.SystemColors.ControlText;
            this.trt_sve.Location = new System.Drawing.Point(78, 296);
            this.trt_sve.Name = "trt_sve";
            this.trt_sve.Size = new System.Drawing.Size(87, 20);
            this.trt_sve.TabIndex = 91;
            this.trt_sve.Text = "Save";
            this.trt_sve.UseVisualStyleBackColor = false;
            this.trt_sve.Click += new System.EventHandler(this.trt_sve_Click);
            // 
            // trtmnts
            // 
            this.trtmnts.AutoSize = true;
            this.trtmnts.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trtmnts.Location = new System.Drawing.Point(191, 38);
            this.trtmnts.Name = "trtmnts";
            this.trtmnts.Size = new System.Drawing.Size(108, 16);
            this.trtmnts.TabIndex = 88;
            this.trtmnts.Text = "Treatments";
            // 
            // trt_add
            // 
            this.trt_add.BackColor = System.Drawing.SystemColors.Control;
            this.trt_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.trt_add.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trt_add.Location = new System.Drawing.Point(194, 96);
            this.trt_add.Name = "trt_add";
            this.trt_add.Size = new System.Drawing.Size(40, 21);
            this.trt_add.TabIndex = 93;
            this.trt_add.Text = "Add";
            this.trt_add.UseVisualStyleBackColor = false;
            this.trt_add.Click += new System.EventHandler(this.trt_add_Click);
            // 
            // dctr_pnl
            // 
            this.dctr_pnl.Controls.Add(this.dct_cn);
            this.dctr_pnl.Controls.Add(this.label13);
            this.dctr_pnl.Controls.Add(this.dct_gnd);
            this.dctr_pnl.Controls.Add(this.label14);
            this.dctr_pnl.Controls.Add(this.dct_age);
            this.dctr_pnl.Controls.Add(this.label15);
            this.dctr_pnl.Controls.Add(this.label16);
            this.dctr_pnl.Controls.Add(this.dct_bd);
            this.dctr_pnl.Controls.Add(this.label17);
            this.dctr_pnl.Controls.Add(this.dct_adr);
            this.dctr_pnl.Controls.Add(this.dct_ln);
            this.dctr_pnl.Controls.Add(this.dct_fn);
            this.dctr_pnl.Controls.Add(this.label18);
            this.dctr_pnl.Controls.Add(this.dct_ccl);
            this.dctr_pnl.Controls.Add(this.dct_rst);
            this.dctr_pnl.Controls.Add(this.dct_sve);
            this.dctr_pnl.Controls.Add(this.doctor);
            this.dctr_pnl.Location = new System.Drawing.Point(13, 209);
            this.dctr_pnl.Name = "dctr_pnl";
            this.dctr_pnl.Size = new System.Drawing.Size(481, 331);
            this.dctr_pnl.TabIndex = 111;
            this.dctr_pnl.Visible = false;
            // 
            // dct_cn
            // 
            this.dct_cn.Location = new System.Drawing.Point(217, 234);
            this.dct_cn.Name = "dct_cn";
            this.dct_cn.Size = new System.Drawing.Size(202, 20);
            this.dct_cn.TabIndex = 87;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(57, 238);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(168, 16);
            this.label13.TabIndex = 86;
            this.label13.Text = "Contact Number: ";
            // 
            // dct_gnd
            // 
            this.dct_gnd.Location = new System.Drawing.Point(296, 198);
            this.dct_gnd.Name = "dct_gnd";
            this.dct_gnd.Size = new System.Drawing.Size(123, 20);
            this.dct_gnd.TabIndex = 85;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(214, 202);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 16);
            this.label14.TabIndex = 84;
            this.label14.Text = "Gender:";
            // 
            // dct_age
            // 
            this.dct_age.Location = new System.Drawing.Point(114, 198);
            this.dct_age.Name = "dct_age";
            this.dct_age.Size = new System.Drawing.Size(94, 20);
            this.dct_age.TabIndex = 83;
            this.dct_age.TextChanged += new System.EventHandler(this.dct_age_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(57, 202);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(48, 16);
            this.label15.TabIndex = 82;
            this.label15.Text = "Age:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(57, 163);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(88, 16);
            this.label16.TabIndex = 81;
            this.label16.Text = "Address:";
            // 
            // dct_bd
            // 
            this.dct_bd.Location = new System.Drawing.Point(171, 122);
            this.dct_bd.Name = "dct_bd";
            this.dct_bd.Size = new System.Drawing.Size(248, 20);
            this.dct_bd.TabIndex = 80;
            this.dct_bd.Value = new System.DateTime(2018, 2, 10, 17, 31, 59, 0);
            this.dct_bd.ValueChanged += new System.EventHandler(this.dct_bd_ValueChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(57, 126);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(108, 16);
            this.label17.TabIndex = 79;
            this.label17.Text = "Birthdate:";
            // 
            // dct_adr
            // 
            this.dct_adr.Location = new System.Drawing.Point(171, 159);
            this.dct_adr.Name = "dct_adr";
            this.dct_adr.Size = new System.Drawing.Size(248, 20);
            this.dct_adr.TabIndex = 78;
            // 
            // dct_ln
            // 
            this.dct_ln.Location = new System.Drawing.Point(298, 82);
            this.dct_ln.Name = "dct_ln";
            this.dct_ln.Size = new System.Drawing.Size(121, 20);
            this.dct_ln.TabIndex = 77;
            // 
            // dct_fn
            // 
            this.dct_fn.Location = new System.Drawing.Point(171, 82);
            this.dct_fn.Name = "dct_fn";
            this.dct_fn.Size = new System.Drawing.Size(121, 20);
            this.dct_fn.TabIndex = 76;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(57, 86);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(58, 16);
            this.label18.TabIndex = 75;
            this.label18.Text = "Name:";
            // 
            // dct_ccl
            // 
            this.dct_ccl.BackColor = System.Drawing.SystemColors.Control;
            this.dct_ccl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dct_ccl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dct_ccl.Location = new System.Drawing.Point(332, 287);
            this.dct_ccl.Name = "dct_ccl";
            this.dct_ccl.Size = new System.Drawing.Size(87, 20);
            this.dct_ccl.TabIndex = 72;
            this.dct_ccl.Text = "Cancel";
            this.dct_ccl.UseVisualStyleBackColor = false;
            this.dct_ccl.Click += new System.EventHandler(this.dct_ccl_Click);
            // 
            // dct_rst
            // 
            this.dct_rst.BackColor = System.Drawing.SystemColors.Control;
            this.dct_rst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dct_rst.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dct_rst.Location = new System.Drawing.Point(208, 287);
            this.dct_rst.Name = "dct_rst";
            this.dct_rst.Size = new System.Drawing.Size(87, 20);
            this.dct_rst.TabIndex = 73;
            this.dct_rst.Text = "Reset";
            this.dct_rst.UseVisualStyleBackColor = false;
            this.dct_rst.Click += new System.EventHandler(this.dct_rst_Click);
            // 
            // dct_sve
            // 
            this.dct_sve.BackColor = System.Drawing.SystemColors.Control;
            this.dct_sve.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dct_sve.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dct_sve.ForeColor = System.Drawing.SystemColors.ControlText;
            this.dct_sve.Location = new System.Drawing.Point(78, 287);
            this.dct_sve.Name = "dct_sve";
            this.dct_sve.Size = new System.Drawing.Size(87, 20);
            this.dct_sve.TabIndex = 74;
            this.dct_sve.Text = "Save";
            this.dct_sve.UseVisualStyleBackColor = false;
            this.dct_sve.Click += new System.EventHandler(this.dct_sve_Click);
            // 
            // doctor
            // 
            this.doctor.AutoSize = true;
            this.doctor.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.doctor.Location = new System.Drawing.Point(191, 33);
            this.doctor.Name = "doctor";
            this.doctor.Size = new System.Drawing.Size(108, 16);
            this.doctor.TabIndex = 1;
            this.doctor.Text = "Add Doctor";
            // 
            // ptn_pnl
            // 
            this.ptn_pnl.Controls.Add(this.ptn_ccl);
            this.ptn_pnl.Controls.Add(this.ptn_rst);
            this.ptn_pnl.Controls.Add(this.pnl_sv);
            this.ptn_pnl.Controls.Add(this.ptn_cn);
            this.ptn_pnl.Controls.Add(this.label12);
            this.ptn_pnl.Controls.Add(this.ptn_gnd);
            this.ptn_pnl.Controls.Add(this.label11);
            this.ptn_pnl.Controls.Add(this.ptn_age);
            this.ptn_pnl.Controls.Add(this.label10);
            this.ptn_pnl.Controls.Add(this.label9);
            this.ptn_pnl.Controls.Add(this.ptn_bd);
            this.ptn_pnl.Controls.Add(this.label4);
            this.ptn_pnl.Controls.Add(this.ptn_adr);
            this.ptn_pnl.Controls.Add(this.ptn_ln);
            this.ptn_pnl.Controls.Add(this.ptn_fn);
            this.ptn_pnl.Controls.Add(this.label3);
            this.ptn_pnl.Controls.Add(this.label2);
            this.ptn_pnl.Location = new System.Drawing.Point(13, 209);
            this.ptn_pnl.Name = "ptn_pnl";
            this.ptn_pnl.Size = new System.Drawing.Size(481, 331);
            this.ptn_pnl.TabIndex = 109;
            this.ptn_pnl.Visible = false;
            // 
            // ptn_ccl
            // 
            this.ptn_ccl.BackColor = System.Drawing.SystemColors.Control;
            this.ptn_ccl.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ptn_ccl.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptn_ccl.Location = new System.Drawing.Point(336, 295);
            this.ptn_ccl.Name = "ptn_ccl";
            this.ptn_ccl.Size = new System.Drawing.Size(87, 20);
            this.ptn_ccl.TabIndex = 58;
            this.ptn_ccl.Text = "Cancel";
            this.ptn_ccl.UseVisualStyleBackColor = false;
            this.ptn_ccl.Click += new System.EventHandler(this.ptn_ccl_Click);
            // 
            // ptn_rst
            // 
            this.ptn_rst.BackColor = System.Drawing.SystemColors.Control;
            this.ptn_rst.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.ptn_rst.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptn_rst.Location = new System.Drawing.Point(212, 295);
            this.ptn_rst.Name = "ptn_rst";
            this.ptn_rst.Size = new System.Drawing.Size(87, 20);
            this.ptn_rst.TabIndex = 58;
            this.ptn_rst.Text = "Reset";
            this.ptn_rst.UseVisualStyleBackColor = false;
            this.ptn_rst.Click += new System.EventHandler(this.ptn_rst_Click);
            // 
            // pnl_sv
            // 
            this.pnl_sv.BackColor = System.Drawing.SystemColors.Control;
            this.pnl_sv.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.pnl_sv.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnl_sv.ForeColor = System.Drawing.SystemColors.ControlText;
            this.pnl_sv.Location = new System.Drawing.Point(82, 295);
            this.pnl_sv.Name = "pnl_sv";
            this.pnl_sv.Size = new System.Drawing.Size(87, 20);
            this.pnl_sv.TabIndex = 58;
            this.pnl_sv.Text = "Save";
            this.pnl_sv.UseVisualStyleBackColor = false;
            this.pnl_sv.Click += new System.EventHandler(this.pnl_sv_Click);
            // 
            // ptn_cn
            // 
            this.ptn_cn.Location = new System.Drawing.Point(221, 238);
            this.ptn_cn.Name = "ptn_cn";
            this.ptn_cn.Size = new System.Drawing.Size(202, 20);
            this.ptn_cn.TabIndex = 14;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(61, 242);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(168, 16);
            this.label12.TabIndex = 13;
            this.label12.Text = "Contact Number: ";
            // 
            // ptn_gnd
            // 
            this.ptn_gnd.Location = new System.Drawing.Point(300, 202);
            this.ptn_gnd.Name = "ptn_gnd";
            this.ptn_gnd.Size = new System.Drawing.Size(123, 20);
            this.ptn_gnd.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(218, 206);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(78, 16);
            this.label11.TabIndex = 11;
            this.label11.Text = "Gender:";
            // 
            // ptn_age
            // 
            this.ptn_age.Location = new System.Drawing.Point(118, 202);
            this.ptn_age.Name = "ptn_age";
            this.ptn_age.Size = new System.Drawing.Size(94, 20);
            this.ptn_age.TabIndex = 10;
            this.ptn_age.TextChanged += new System.EventHandler(this.ptn_age_TextChanged);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(61, 206);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 16);
            this.label10.TabIndex = 9;
            this.label10.Text = "Age:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(61, 167);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(88, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Address:";
            // 
            // ptn_bd
            // 
            this.ptn_bd.Location = new System.Drawing.Point(175, 126);
            this.ptn_bd.Name = "ptn_bd";
            this.ptn_bd.Size = new System.Drawing.Size(248, 20);
            this.ptn_bd.TabIndex = 7;
            this.ptn_bd.Value = new System.DateTime(2018, 2, 10, 17, 31, 59, 0);
            this.ptn_bd.ValueChanged += new System.EventHandler(this.ptn_bd_ValueChanged);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(61, 130);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 16);
            this.label4.TabIndex = 5;
            this.label4.Text = "Birthdate:";
            // 
            // ptn_adr
            // 
            this.ptn_adr.Location = new System.Drawing.Point(175, 163);
            this.ptn_adr.Name = "ptn_adr";
            this.ptn_adr.Size = new System.Drawing.Size(248, 20);
            this.ptn_adr.TabIndex = 4;
            // 
            // ptn_ln
            // 
            this.ptn_ln.Location = new System.Drawing.Point(302, 86);
            this.ptn_ln.Name = "ptn_ln";
            this.ptn_ln.Size = new System.Drawing.Size(121, 20);
            this.ptn_ln.TabIndex = 3;
            // 
            // ptn_fn
            // 
            this.ptn_fn.Location = new System.Drawing.Point(175, 86);
            this.ptn_fn.Name = "ptn_fn";
            this.ptn_fn.Size = new System.Drawing.Size(121, 20);
            this.ptn_fn.TabIndex = 2;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(61, 90);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(58, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(191, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Add Patient";
            // 
            // ptn_lst_pnl
            // 
            this.ptn_lst_pnl.Controls.Add(this.ptn_nme);
            this.ptn_lst_pnl.Controls.Add(this.closeb);
            this.ptn_lst_pnl.Controls.Add(this.ptn_grid);
            this.ptn_lst_pnl.Controls.Add(this.ptn_add);
            this.ptn_lst_pnl.Controls.Add(this.label21);
            this.ptn_lst_pnl.Location = new System.Drawing.Point(13, 209);
            this.ptn_lst_pnl.Name = "ptn_lst_pnl";
            this.ptn_lst_pnl.Size = new System.Drawing.Size(481, 331);
            this.ptn_lst_pnl.TabIndex = 112;
            this.ptn_lst_pnl.Visible = false;
            // 
            // ptn_nme
            // 
            this.ptn_nme.Location = new System.Drawing.Point(30, 64);
            this.ptn_nme.Name = "ptn_nme";
            this.ptn_nme.Size = new System.Drawing.Size(140, 20);
            this.ptn_nme.TabIndex = 94;
            this.ptn_nme.TextChanged += new System.EventHandler(this.ptn_nme_TextChanged);
            // 
            // closeb
            // 
            this.closeb.BackColor = System.Drawing.SystemColors.Control;
            this.closeb.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.closeb.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.closeb.Location = new System.Drawing.Point(382, 333);
            this.closeb.Name = "closeb";
            this.closeb.Size = new System.Drawing.Size(71, 20);
            this.closeb.TabIndex = 58;
            this.closeb.Text = "Close";
            this.closeb.UseVisualStyleBackColor = false;
            this.closeb.Click += new System.EventHandler(this.closeb_Click);
            // 
            // ptn_grid
            // 
            this.ptn_grid.AllowUserToAddRows = false;
            this.ptn_grid.AllowUserToDeleteRows = false;
            this.ptn_grid.AllowUserToResizeColumns = false;
            this.ptn_grid.AllowUserToResizeRows = false;
            this.ptn_grid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ptn_grid.Location = new System.Drawing.Point(30, 97);
            this.ptn_grid.Name = "ptn_grid";
            this.ptn_grid.ReadOnly = true;
            this.ptn_grid.RowHeadersVisible = false;
            this.ptn_grid.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.ptn_grid.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.ptn_grid.Size = new System.Drawing.Size(423, 204);
            this.ptn_grid.TabIndex = 27;
            this.ptn_grid.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ptn_grid_CellClick);
            this.ptn_grid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ptn_grid_CellContentClick);
            // 
            // ptn_add
            // 
            this.ptn_add.BackColor = System.Drawing.SystemColors.Control;
            this.ptn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ptn_add.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ptn_add.Location = new System.Drawing.Point(176, 63);
            this.ptn_add.Name = "ptn_add";
            this.ptn_add.Size = new System.Drawing.Size(62, 21);
            this.ptn_add.TabIndex = 93;
            this.ptn_add.Text = "Find";
            this.ptn_add.UseVisualStyleBackColor = false;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(168, 28);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(158, 16);
            this.label21.TabIndex = 88;
            this.label21.Text = "Patient Listing";
            // 
            // dct_lst_pnl
            // 
            this.dct_lst_pnl.Controls.Add(this.label20);
            this.dct_lst_pnl.Controls.Add(this.dct_nme);
            this.dct_lst_pnl.Controls.Add(this.dct_close);
            this.dct_lst_pnl.Controls.Add(this.dct_dgv);
            this.dct_lst_pnl.Controls.Add(this.dct_fnd);
            this.dct_lst_pnl.Location = new System.Drawing.Point(13, 209);
            this.dct_lst_pnl.Name = "dct_lst_pnl";
            this.dct_lst_pnl.Size = new System.Drawing.Size(481, 331);
            this.dct_lst_pnl.TabIndex = 113;
            this.dct_lst_pnl.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Lucida Console", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(168, 28);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(148, 16);
            this.label20.TabIndex = 88;
            this.label20.Text = "Doctor Listing";
            // 
            // dct_nme
            // 
            this.dct_nme.Location = new System.Drawing.Point(30, 64);
            this.dct_nme.Name = "dct_nme";
            this.dct_nme.Size = new System.Drawing.Size(140, 20);
            this.dct_nme.TabIndex = 94;
            this.dct_nme.TextChanged += new System.EventHandler(this.dct_nme_TextChanged);
            // 
            // dct_close
            // 
            this.dct_close.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.dct_close.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.dct_close.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dct_close.Location = new System.Drawing.Point(382, 333);
            this.dct_close.Name = "dct_close";
            this.dct_close.Size = new System.Drawing.Size(71, 20);
            this.dct_close.TabIndex = 58;
            this.dct_close.Text = "Close";
            this.dct_close.UseVisualStyleBackColor = false;
            this.dct_close.Click += new System.EventHandler(this.dct_close_Click);
            // 
            // dct_dgv
            // 
            this.dct_dgv.AllowUserToAddRows = false;
            this.dct_dgv.AllowUserToDeleteRows = false;
            this.dct_dgv.AllowUserToResizeColumns = false;
            this.dct_dgv.AllowUserToResizeRows = false;
            this.dct_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dct_dgv.Location = new System.Drawing.Point(30, 97);
            this.dct_dgv.Name = "dct_dgv";
            this.dct_dgv.ReadOnly = true;
            this.dct_dgv.RowHeadersVisible = false;
            this.dct_dgv.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dct_dgv.Size = new System.Drawing.Size(423, 204);
            this.dct_dgv.TabIndex = 27;
            this.dct_dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dct_dgv_CellClick);
            this.dct_dgv.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dct_dgv_CellContentClick);
            // 
            // dct_fnd
            // 
            this.dct_fnd.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.dct_fnd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.dct_fnd.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dct_fnd.Location = new System.Drawing.Point(176, 63);
            this.dct_fnd.Name = "dct_fnd";
            this.dct_fnd.Size = new System.Drawing.Size(62, 21);
            this.dct_fnd.TabIndex = 93;
            this.dct_fnd.Text = "Find";
            this.dct_fnd.UseVisualStyleBackColor = false;
            // 
            // sched_id
            // 
            this.sched_id.AutoSize = true;
            this.sched_id.Location = new System.Drawing.Point(300, 3);
            this.sched_id.Name = "sched_id";
            this.sched_id.Size = new System.Drawing.Size(41, 13);
            this.sched_id.TabIndex = 117;
            this.sched_id.Text = "label20";
            this.sched_id.Visible = false;
            // 
            // docid
            // 
            this.docid.AutoSize = true;
            this.docid.Location = new System.Drawing.Point(301, 12);
            this.docid.Name = "docid";
            this.docid.Size = new System.Drawing.Size(41, 13);
            this.docid.TabIndex = 116;
            this.docid.Text = "label20";
            // 
            // patientname
            // 
            this.patientname.AutoSize = true;
            this.patientname.Location = new System.Drawing.Point(302, -1);
            this.patientname.Name = "patientname";
            this.patientname.Size = new System.Drawing.Size(41, 13);
            this.patientname.TabIndex = 115;
            this.patientname.Text = "label20";
            this.patientname.Visible = false;
            // 
            // datetime
            // 
            this.datetime.AutoSize = true;
            this.datetime.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.datetime.Location = new System.Drawing.Point(446, 12);
            this.datetime.Name = "datetime";
            this.datetime.Size = new System.Drawing.Size(0, 11);
            this.datetime.TabIndex = 108;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(389, 12);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(47, 11);
            this.label8.TabIndex = 107;
            this.label8.Text = "Today:";
            // 
            // details
            // 
            this.details.Controls.Add(this.rsts);
            this.details.Controls.Add(this.src_dct);
            this.details.Controls.Add(this.src_ptn);
            this.details.Controls.Add(this.addsch);
            this.details.Controls.Add(this.add_dtr);
            this.details.Controls.Add(this.add_ptn);
            this.details.Controls.Add(this.dctr_nm);
            this.details.Controls.Add(this.dctr);
            this.details.Controls.Add(this.trt_btn);
            this.details.Controls.Add(this.es);
            this.details.Controls.Add(this.em);
            this.details.Controls.Add(this.label7);
            this.details.Controls.Add(this.ehr);
            this.details.Controls.Add(this.ss);
            this.details.Controls.Add(this.sm);
            this.details.Controls.Add(this.label6);
            this.details.Controls.Add(this.shr);
            this.details.Controls.Add(this.dtpkr);
            this.details.Controls.Add(this.patn);
            this.details.Controls.Add(this.label5);
            this.details.Controls.Add(this.endt);
            this.details.Controls.Add(this.startt);
            this.details.Controls.Add(this.appdate);
            this.details.Controls.Add(this.patient);
            this.details.Location = new System.Drawing.Point(7, 66);
            this.details.Name = "details";
            this.details.Size = new System.Drawing.Size(866, 106);
            this.details.TabIndex = 106;
            this.details.TabStop = false;
            this.details.Text = "Appointent Details";
            // 
            // rsts
            // 
            this.rsts.BackColor = System.Drawing.SystemColors.Control;
            this.rsts.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.rsts.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rsts.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.rsts.Location = new System.Drawing.Point(653, 55);
            this.rsts.Name = "rsts";
            this.rsts.Size = new System.Drawing.Size(193, 20);
            this.rsts.TabIndex = 65;
            this.rsts.Text = "Reset";
            this.rsts.UseVisualStyleBackColor = false;
            this.rsts.Click += new System.EventHandler(this.rsts_Click);
            // 
            // src_dct
            // 
            this.src_dct.BackgroundImage = global::Accounting.Properties.Resources.logo_big_searchoptimization1;
            this.src_dct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.src_dct.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.src_dct.Image = ((System.Drawing.Image)(resources.GetObject("src_dct.Image")));
            this.src_dct.Location = new System.Drawing.Point(242, 67);
            this.src_dct.Name = "src_dct";
            this.src_dct.Size = new System.Drawing.Size(35, 20);
            this.src_dct.TabIndex = 64;
            this.src_dct.Text = "Go";
            this.src_dct.UseVisualStyleBackColor = true;
            this.src_dct.Click += new System.EventHandler(this.src_dct_Click);
            // 
            // src_ptn
            // 
            this.src_ptn.BackgroundImage = global::Accounting.Properties.Resources.logo_big_searchoptimization1;
            this.src_ptn.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.src_ptn.Font = new System.Drawing.Font("Microsoft Sans Serif", 5.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.src_ptn.Image = ((System.Drawing.Image)(resources.GetObject("src_ptn.Image")));
            this.src_ptn.Location = new System.Drawing.Point(242, 16);
            this.src_ptn.Name = "src_ptn";
            this.src_ptn.Size = new System.Drawing.Size(35, 20);
            this.src_ptn.TabIndex = 63;
            this.src_ptn.Text = "Go";
            this.src_ptn.UseVisualStyleBackColor = true;
            this.src_ptn.Click += new System.EventHandler(this.src_ptn_Click);
            // 
            // addsch
            // 
            this.addsch.BackColor = System.Drawing.SystemColors.Control;
            this.addsch.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.addsch.Font = new System.Drawing.Font("Lucida Console", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addsch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.addsch.Location = new System.Drawing.Point(653, 32);
            this.addsch.Name = "addsch";
            this.addsch.Size = new System.Drawing.Size(193, 20);
            this.addsch.TabIndex = 26;
            this.addsch.Text = "Add Schedule";
            this.addsch.UseVisualStyleBackColor = false;
            this.addsch.Click += new System.EventHandler(this.addsch_Click);
            // 
            // add_dtr
            // 
            this.add_dtr.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_dtr.Location = new System.Drawing.Point(283, 67);
            this.add_dtr.Name = "add_dtr";
            this.add_dtr.Size = new System.Drawing.Size(45, 20);
            this.add_dtr.TabIndex = 62;
            this.add_dtr.Text = "...";
            this.add_dtr.UseVisualStyleBackColor = true;
            this.add_dtr.Click += new System.EventHandler(this.add_dtr_Click);
            // 
            // add_ptn
            // 
            this.add_ptn.Font = new System.Drawing.Font("Lucida Console", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.add_ptn.Location = new System.Drawing.Point(283, 17);
            this.add_ptn.Name = "add_ptn";
            this.add_ptn.Size = new System.Drawing.Size(45, 20);
            this.add_ptn.TabIndex = 61;
            this.add_ptn.Text = "...";
            this.add_ptn.UseVisualStyleBackColor = true;
            this.add_ptn.Click += new System.EventHandler(this.add_ptn_Click);
            // 
            // dctr_nm
            // 
            this.dctr_nm.Location = new System.Drawing.Point(104, 67);
            this.dctr_nm.Name = "dctr_nm";
            this.dctr_nm.Size = new System.Drawing.Size(142, 20);
            this.dctr_nm.TabIndex = 60;
            // 
            // dctr
            // 
            this.dctr.AutoSize = true;
            this.dctr.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dctr.Location = new System.Drawing.Point(42, 70);
            this.dctr.Name = "dctr";
            this.dctr.Size = new System.Drawing.Size(54, 11);
            this.dctr.TabIndex = 59;
            this.dctr.Text = "Doctor:";
            // 
            // trt_btn
            // 
            this.trt_btn.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.trt_btn.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.trt_btn.Location = new System.Drawing.Point(104, 40);
            this.trt_btn.Name = "trt_btn";
            this.trt_btn.Size = new System.Drawing.Size(142, 23);
            this.trt_btn.TabIndex = 58;
            this.trt_btn.Text = "Select Treatment";
            this.trt_btn.UseVisualStyleBackColor = true;
            this.trt_btn.Click += new System.EventHandler(this.trt_btn_Click);
            // 
            // es
            // 
            this.es.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.es.FormattingEnabled = true;
            this.es.Items.AddRange(new object[] {
            "AM",
            "PM"});
            this.es.Location = new System.Drawing.Point(578, 59);
            this.es.Name = "es";
            this.es.Size = new System.Drawing.Size(36, 21);
            this.es.TabIndex = 14;
            // 
            // em
            // 
            this.em.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.em.FormattingEnabled = true;
            this.em.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "20",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55"});
            this.em.Location = new System.Drawing.Point(529, 59);
            this.em.Name = "em";
            this.em.Size = new System.Drawing.Size(36, 21);
            this.em.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(510, 61);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(20, 19);
            this.label7.TabIndex = 12;
            this.label7.Text = ":";
            // 
            // ehr
            // 
            this.ehr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ehr.FormattingEnabled = true;
            this.ehr.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.ehr.Location = new System.Drawing.Point(472, 59);
            this.ehr.Name = "ehr";
            this.ehr.Size = new System.Drawing.Size(36, 21);
            this.ehr.TabIndex = 11;
            // 
            // ss
            // 
            this.ss.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ss.FormattingEnabled = true;
            this.ss.Items.AddRange(new object[] {
            "AM",
            "PM"});
            this.ss.Location = new System.Drawing.Point(578, 35);
            this.ss.Name = "ss";
            this.ss.Size = new System.Drawing.Size(36, 21);
            this.ss.TabIndex = 10;
            // 
            // sm
            // 
            this.sm.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sm.FormattingEnabled = true;
            this.sm.Items.AddRange(new object[] {
            "00",
            "05",
            "10",
            "15",
            "25",
            "30",
            "35",
            "40",
            "45",
            "50",
            "55"});
            this.sm.Location = new System.Drawing.Point(529, 35);
            this.sm.Name = "sm";
            this.sm.Size = new System.Drawing.Size(36, 21);
            this.sm.TabIndex = 9;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Lucida Console", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(510, 37);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(20, 19);
            this.label6.TabIndex = 8;
            this.label6.Text = ":";
            // 
            // shr
            // 
            this.shr.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.shr.FormattingEnabled = true;
            this.shr.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10",
            "11",
            "12"});
            this.shr.Location = new System.Drawing.Point(472, 35);
            this.shr.Name = "shr";
            this.shr.Size = new System.Drawing.Size(36, 21);
            this.shr.TabIndex = 7;
            this.shr.SelectedIndexChanged += new System.EventHandler(this.shr_SelectedIndexChanged);
            // 
            // dtpkr
            // 
            this.dtpkr.CustomFormat = "yyyy-MM-dd";
            this.dtpkr.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpkr.Location = new System.Drawing.Point(470, 9);
            this.dtpkr.Name = "dtpkr";
            this.dtpkr.Size = new System.Drawing.Size(144, 20);
            this.dtpkr.TabIndex = 6;
            this.dtpkr.Value = new System.DateTime(2018, 2, 10, 17, 31, 59, 0);
            // 
            // patn
            // 
            this.patn.Location = new System.Drawing.Point(104, 16);
            this.patn.Name = "patn";
            this.patn.Size = new System.Drawing.Size(142, 20);
            this.patn.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(23, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 11);
            this.label5.TabIndex = 4;
            this.label5.Text = "Treatment: ";
            // 
            // endt
            // 
            this.endt.AutoSize = true;
            this.endt.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.endt.Location = new System.Drawing.Point(373, 64);
            this.endt.Name = "endt";
            this.endt.Size = new System.Drawing.Size(89, 11);
            this.endt.TabIndex = 3;
            this.endt.Text = "Ending Time:";
            // 
            // startt
            // 
            this.startt.AutoSize = true;
            this.startt.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.startt.Location = new System.Drawing.Point(359, 41);
            this.startt.Name = "startt";
            this.startt.Size = new System.Drawing.Size(103, 11);
            this.startt.TabIndex = 2;
            this.startt.Text = "Starting Time:";
            // 
            // appdate
            // 
            this.appdate.AutoSize = true;
            this.appdate.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.appdate.Location = new System.Drawing.Point(340, 17);
            this.appdate.Name = "appdate";
            this.appdate.Size = new System.Drawing.Size(124, 11);
            this.appdate.TabIndex = 1;
            this.appdate.Text = "Appointment Date:";
            // 
            // patient
            // 
            this.patient.AutoSize = true;
            this.patient.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.patient.Location = new System.Drawing.Point(9, 21);
            this.patient.Name = "patient";
            this.patient.Size = new System.Drawing.Size(96, 11);
            this.patient.TabIndex = 0;
            this.patient.Text = "Patient Name:";
            // 
            // adschp
            // 
            this.adschp.Controls.Add(this.FinishS);
            this.adschp.Controls.Add(this.EditS);
            this.adschp.Controls.Add(this.AddS);
            this.adschp.Controls.Add(this.CancelS);
            this.adschp.Location = new System.Drawing.Point(726, 207);
            this.adschp.Name = "adschp";
            this.adschp.Size = new System.Drawing.Size(146, 92);
            this.adschp.TabIndex = 58;
            this.adschp.Visible = false;
            // 
            // FinishS
            // 
            this.FinishS.BackColor = System.Drawing.SystemColors.Control;
            this.FinishS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.FinishS.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FinishS.Location = new System.Drawing.Point(12, 58);
            this.FinishS.Name = "FinishS";
            this.FinishS.Size = new System.Drawing.Size(126, 20);
            this.FinishS.TabIndex = 57;
            this.FinishS.Text = "Finish Appointment";
            this.FinishS.UseVisualStyleBackColor = false;
            this.FinishS.Visible = false;
            this.FinishS.Click += new System.EventHandler(this.FinishS_Click);
            // 
            // EditS
            // 
            this.EditS.BackColor = System.Drawing.SystemColors.Control;
            this.EditS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.EditS.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EditS.Location = new System.Drawing.Point(12, 32);
            this.EditS.Name = "EditS";
            this.EditS.Size = new System.Drawing.Size(126, 20);
            this.EditS.TabIndex = 18;
            this.EditS.Text = "Edit Schedule";
            this.EditS.UseVisualStyleBackColor = false;
            this.EditS.Click += new System.EventHandler(this.EditS_Click);
            // 
            // AddS
            // 
            this.AddS.BackColor = System.Drawing.SystemColors.Control;
            this.AddS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.AddS.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddS.ForeColor = System.Drawing.SystemColors.ControlText;
            this.AddS.Location = new System.Drawing.Point(12, 6);
            this.AddS.Name = "AddS";
            this.AddS.Size = new System.Drawing.Size(126, 20);
            this.AddS.TabIndex = 17;
            this.AddS.Text = "Add Appointment\r\n";
            this.AddS.UseVisualStyleBackColor = false;
            this.AddS.Click += new System.EventHandler(this.AddS_Click);
            // 
            // CancelS
            // 
            this.CancelS.BackColor = System.Drawing.SystemColors.Control;
            this.CancelS.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.CancelS.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CancelS.Location = new System.Drawing.Point(12, 58);
            this.CancelS.Name = "CancelS";
            this.CancelS.Size = new System.Drawing.Size(126, 20);
            this.CancelS.TabIndex = 56;
            this.CancelS.Text = "Cancel Schedule";
            this.CancelS.UseVisualStyleBackColor = false;
            this.CancelS.Click += new System.EventHandler(this.CancelS_Click);
            // 
            // Appointment
            // 
            this.Appointment.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Appointment.Location = new System.Drawing.Point(158, 178);
            this.Appointment.Name = "Appointment";
            this.Appointment.Size = new System.Drawing.Size(132, 25);
            this.Appointment.TabIndex = 104;
            this.Appointment.Text = "View Appointments";
            this.Appointment.UseVisualStyleBackColor = true;
            this.Appointment.Click += new System.EventHandler(this.Appointment_Click);
            // 
            // Schedule
            // 
            this.Schedule.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Schedule.Location = new System.Drawing.Point(20, 178);
            this.Schedule.Name = "Schedule";
            this.Schedule.Size = new System.Drawing.Size(132, 25);
            this.Schedule.TabIndex = 103;
            this.Schedule.Text = "View Schedules";
            this.Schedule.UseVisualStyleBackColor = true;
            this.Schedule.Click += new System.EventHandler(this.Schedule_Click);
            // 
            // dgv_app
            // 
            this.dgv_app.AllowUserToAddRows = false;
            this.dgv_app.AllowUserToDeleteRows = false;
            this.dgv_app.AllowUserToResizeColumns = false;
            this.dgv_app.AllowUserToResizeRows = false;
            this.dgv_app.BackgroundColor = System.Drawing.Color.White;
            this.dgv_app.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgv_app.Location = new System.Drawing.Point(16, 207);
            this.dgv_app.Name = "dgv_app";
            this.dgv_app.ReadOnly = true;
            this.dgv_app.RowHeadersVisible = false;
            this.dgv_app.Size = new System.Drawing.Size(704, 331);
            this.dgv_app.TabIndex = 114;
            this.dgv_app.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_app_CellContentClick);
            // 
            // dgv_sched
            // 
            this.dgv_sched.AllowUserToResizeColumns = false;
            this.dgv_sched.AllowUserToResizeRows = false;
            this.dgv_sched.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_sched.Location = new System.Drawing.Point(13, 207);
            this.dgv_sched.Name = "dgv_sched";
            this.dgv_sched.ReadOnly = true;
            this.dgv_sched.RowHeadersVisible = false;
            this.dgv_sched.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.dgv_sched.Size = new System.Drawing.Size(707, 329);
            this.dgv_sched.TabIndex = 105;
            this.dgv_sched.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_sched_CellContentClick);
            // 
            // btn_allsched
            // 
            this.btn_allsched.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_allsched.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_allsched.Location = new System.Drawing.Point(589, 184);
            this.btn_allsched.Name = "btn_allsched";
            this.btn_allsched.Size = new System.Drawing.Size(131, 20);
            this.btn_allsched.TabIndex = 118;
            this.btn_allsched.Text = "All Schedule";
            this.btn_allsched.UseVisualStyleBackColor = true;
            this.btn_allsched.Click += new System.EventHandler(this.btn_allsched_Click);
            // 
            // btn_allapp
            // 
            this.btn_allapp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_allapp.Font = new System.Drawing.Font("Lucida Console", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_allapp.Location = new System.Drawing.Point(589, 184);
            this.btn_allapp.Name = "btn_allapp";
            this.btn_allapp.Size = new System.Drawing.Size(131, 19);
            this.btn_allapp.TabIndex = 119;
            this.btn_allapp.Text = "All Appointment";
            this.btn_allapp.UseVisualStyleBackColor = true;
            this.btn_allapp.Click += new System.EventHandler(this.btn_allapp_Click);
            // 
            // app_id
            // 
            this.app_id.AutoSize = true;
            this.app_id.Location = new System.Drawing.Point(10, 23);
            this.app_id.Name = "app_id";
            this.app_id.Size = new System.Drawing.Size(41, 13);
            this.app_id.TabIndex = 120;
            this.app_id.Text = "label20";
            this.app_id.Visible = false;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Lucida Console", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(6, 6);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(270, 37);
            this.label19.TabIndex = 316;
            this.label19.Text = "Appointment";
            // 
            // dntid
            // 
            this.dntid.AutoSize = true;
            this.dntid.Location = new System.Drawing.Point(346, 4);
            this.dntid.Name = "dntid";
            this.dntid.Size = new System.Drawing.Size(41, 13);
            this.dntid.TabIndex = 317;
            this.dntid.Text = "label20";
            this.dntid.Visible = false;
            // 
            // panelista
            // 
            this.panelista.Controls.Add(this.dntid);
            this.panelista.Controls.Add(this.app_id);
            this.panelista.Controls.Add(this.sched_id);
            this.panelista.Location = new System.Drawing.Point(0, -1);
            this.panelista.Name = "panelista";
            this.panelista.Size = new System.Drawing.Size(880, 595);
            this.panelista.TabIndex = 318;
            // 
            // form_appointment
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(880, 590);
            this.Controls.Add(this.panelista);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.trmnt_pnl);
            this.Controls.Add(this.dctr_pnl);
            this.Controls.Add(this.adschp);
            this.Controls.Add(this.ptn_pnl);
            this.Controls.Add(this.ptn_lst_pnl);
            this.Controls.Add(this.dct_lst_pnl);
            this.Controls.Add(this.dgv_app);
            this.Controls.Add(this.dgv_sched);
            this.Controls.Add(this.btn_allapp);
            this.Controls.Add(this.btn_allsched);
            this.Controls.Add(this.docid);
            this.Controls.Add(this.patientname);
            this.Controls.Add(this.datetime);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.details);
            this.Controls.Add(this.Appointment);
            this.Controls.Add(this.Schedule);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "form_appointment";
            this.Text = "form_appointment";
            this.Load += new System.EventHandler(this.form_appointment_Load);
            this.trmnt_pnl.ResumeLayout(false);
            this.trmnt_pnl.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.trt_grid)).EndInit();
            this.dctr_pnl.ResumeLayout(false);
            this.dctr_pnl.PerformLayout();
            this.ptn_pnl.ResumeLayout(false);
            this.ptn_pnl.PerformLayout();
            this.ptn_lst_pnl.ResumeLayout(false);
            this.ptn_lst_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ptn_grid)).EndInit();
            this.dct_lst_pnl.ResumeLayout(false);
            this.dct_lst_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dct_dgv)).EndInit();
            this.details.ResumeLayout(false);
            this.details.PerformLayout();
            this.adschp.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_app)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sched)).EndInit();
            this.panelista.ResumeLayout(false);
            this.panelista.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel trmnt_pnl;
        private System.Windows.Forms.Button trt_add1;
        private System.Windows.Forms.Label romeo;
        private System.Windows.Forms.Label sched_id1;
        private System.Windows.Forms.ComboBox trmnt_cmb;
        private System.Windows.Forms.Label trt_id;
        private System.Windows.Forms.Label countrows;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView trt_grid;
        private System.Windows.Forms.Button trt_cncl;
        private System.Windows.Forms.Button trt_sve;
        private System.Windows.Forms.Label trtmnts;
        private System.Windows.Forms.Button trt_add;
        private System.Windows.Forms.Panel dctr_pnl;
        private System.Windows.Forms.TextBox dct_cn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox dct_gnd;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox dct_age;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.DateTimePicker dct_bd;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox dct_adr;
        private System.Windows.Forms.TextBox dct_ln;
        private System.Windows.Forms.TextBox dct_fn;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button dct_ccl;
        private System.Windows.Forms.Button dct_rst;
        private System.Windows.Forms.Button dct_sve;
        private System.Windows.Forms.Label doctor;
        private System.Windows.Forms.Panel ptn_pnl;
        private System.Windows.Forms.Button ptn_ccl;
        private System.Windows.Forms.Button ptn_rst;
        private System.Windows.Forms.Button pnl_sv;
        private System.Windows.Forms.TextBox ptn_cn;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox ptn_gnd;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox ptn_age;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.DateTimePicker ptn_bd;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox ptn_adr;
        private System.Windows.Forms.TextBox ptn_ln;
        private System.Windows.Forms.TextBox ptn_fn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel ptn_lst_pnl;
        private System.Windows.Forms.TextBox ptn_nme;
        private System.Windows.Forms.Button closeb;
        private System.Windows.Forms.DataGridView ptn_grid;
        private System.Windows.Forms.Button ptn_add;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel dct_lst_pnl;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox dct_nme;
        private System.Windows.Forms.Button dct_close;
        private System.Windows.Forms.DataGridView dct_dgv;
        private System.Windows.Forms.Button dct_fnd;
        private System.Windows.Forms.Label sched_id;
        private System.Windows.Forms.Label docid;
        private System.Windows.Forms.Label patientname;
        private System.Windows.Forms.Label datetime;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox details;
        private System.Windows.Forms.Button src_dct;
        private System.Windows.Forms.Button src_ptn;
        private System.Windows.Forms.Button addsch;
        private System.Windows.Forms.Panel adschp;
        private System.Windows.Forms.Button EditS;
        private System.Windows.Forms.Button AddS;
        private System.Windows.Forms.Button CancelS;
        private System.Windows.Forms.Button add_dtr;
        private System.Windows.Forms.Button add_ptn;
        private System.Windows.Forms.TextBox dctr_nm;
        private System.Windows.Forms.Label dctr;
        private System.Windows.Forms.Button trt_btn;
        private System.Windows.Forms.ComboBox es;
        private System.Windows.Forms.ComboBox em;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox ehr;
        private System.Windows.Forms.ComboBox ss;
        private System.Windows.Forms.ComboBox sm;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox shr;
        private System.Windows.Forms.DateTimePicker dtpkr;
        private System.Windows.Forms.TextBox patn;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label endt;
        private System.Windows.Forms.Label startt;
        private System.Windows.Forms.Label appdate;
        private System.Windows.Forms.Label patient;
        private System.Windows.Forms.Button Appointment;
        private System.Windows.Forms.Button Schedule;
        private System.Windows.Forms.DataGridView dgv_app;
        private System.Windows.Forms.DataGridView dgv_sched;
        private System.Windows.Forms.Button btn_allsched;
        private System.Windows.Forms.Button btn_allapp;
        private System.Windows.Forms.Button FinishS;
        private System.Windows.Forms.Label app_id;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label dntid;
        private System.Windows.Forms.Button trt_rmv;
        private System.Windows.Forms.Button rsts;
        private System.Windows.Forms.Label alpha;
        private System.Windows.Forms.Panel panelista;
    }
}